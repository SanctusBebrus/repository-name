import io
import sys
import sqlite3

from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap


tmp = '''<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>MainWindow</class>
 <widget class="QMainWindow" name="MainWindow">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>605</width>
    <height>704</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>Поставьте 100 баллов</string>
  </property>
  <widget class="QWidget" name="centralwidget">
   <widget class="QListWidget" name="listWidget">
    <property name="geometry">
     <rect>
      <x>20</x>
      <y>180</y>
      <width>561</width>
      <height>451</height>
     </rect>
    </property>
   </widget>
   <widget class="QPushButton" name="pushButton">
    <property name="geometry">
     <rect>
      <x>380</x>
      <y>50</y>
      <width>201</width>
      <height>91</height>
     </rect>
    </property>
    <property name="text">
     <string>Искать</string>
    </property>
   </widget>
   <widget class="QLineEdit" name="lineEdit">
    <property name="geometry">
     <rect>
      <x>20</x>
      <y>101</y>
      <width>321</width>
      <height>41</height>
     </rect>
    </property>
   </widget>
   <widget class="QComboBox" name="comboBox">
    <property name="geometry">
     <rect>
      <x>20</x>
      <y>50</y>
      <width>321</width>
      <height>41</height>
     </rect>
    </property>
   </widget>
   <widget class="QPushButton" name="pushButton_2">
    <property name="geometry">
     <rect>
      <x>450</x>
      <y>650</y>
      <width>131</width>
      <height>41</height>
     </rect>
    </property>
    <property name="text">
     <string>Открыть</string>
    </property>
   </widget>
  </widget>
 </widget>
 <resources/>
 <connections/>
</ui>
'''


class Dialog(QDialog):
    def __init__(self):
        super(Dialog, self).__init__()

        self.setStyleSheet("QLabel { font-weight: bold; font-size: 15px; } QDialog { background-color: #eb9175 }")
        self.setGeometry(300, 300, 500, 500)
        self.setWindowTitle("Книга")

        self.image = QLabel(self)
        self.image.move(150, 10)
        self.image.resize(200, 300)

        self.txt = QLabel(self)
        self.txt.setText('Название :')
        self.txt.move(10, 350)
        self.txt.resize(700, 20)

        self.txt_author = QLabel(self)
        self.txt_author.setText("Автор :")
        self.txt_author.move(10, 380)
        self.txt_author.resize(300, 20)

        self.txt_genre = QLabel(self)
        self.txt_genre.setText("Жанр :")
        self.txt_genre.move(10, 410)
        self.txt_genre.resize(300, 20)

        self.txt_year = QLabel(self)
        self.txt_year.setText("Год выпуска : ")
        self.txt_year.move(10, 440)
        self.txt_year.resize(300, 20)

    def information(self, book):
        con = sqlite3.connect('library.db')
        cur = con.cursor()
        result = cur.execute(f"""SELECT Название, Автор, [Год издания], Жанр, Изображение FROM books
            WHERE Название == '{book}'""").fetchall()
        print(book)
        result = result[0]
        book = result[0]
        author = result[1]
        year = result[2]
        genre = result[3]
        image = result[4]
        self.txt.setText('Название :        ' + str(book))
        self.txt_author.setText("Автор :               " + author)
        self.txt_year.setText("Год выпуска :  " + str(year))
        self.txt_genre.setText("Жанр :                " + genre)
        self.image.setPixmap(QPixmap(image).scaled(200, 300))


class Window(QMainWindow):
    def __init__(self):
        super(Window, self).__init__()

        f = io.StringIO(tmp)
        uic.loadUi(f, self)

        self.text = 'Название'
        self.setWindowTitle("Библиотека лучших книг")
        self.comboBox.addItems(['Название', 'Автор'])
        self.comboBox.activated[str].connect(self.onActivated)

        con = sqlite3.connect('library.db')
        cur = con.cursor()
        result = cur.execute("""SELECT Название FROM books""").fetchall()

        self.name = []
        for i in result:
            self.name.append(i[0])
        self.pushButton.clicked.connect(self.clickFound)
        self.pushButton_2.clicked.connect(self.clickOPen)

        for i in self.name:
            self.listWidget.addItem('  ' + str(i))

    def onActivated(self, text):
        self.text = text

    def clickOPen(self):
        name = self.name[self.listWidget.currentRow()]
        print(self.name)
        print(self.listWidget.currentRow())
        window = Dialog()
        window.information(name)
        window.show()
        window.exec()

    def clickFound(self):
        text = self.lineEdit.text()
        if self.text == 'Название':
            con = sqlite3.connect('library.db')
            cur = con.cursor()
            result = cur.execute(f"""SELECT Название FROM books WHERE Название LIKE '%{text}%' """).fetchall()
            self.name = [i[0] for i in result]
            print(self.name)
            self.listWidget.clear()
            for i in self.name:
                self.listWidget.addItem('  ' + str(i))
        else:
            con = sqlite3.connect('library.db')
            cur = con.cursor()
            result = cur.execute(f"""SELECT Название FROM books WHERE Автор LIKE '%{text}%' """).fetchall()
            self.name = [i[0] for i in result]
            self.listWidget.clear()
            for i in self.name:
                self.listWidget.addItem('  ' + str(i))


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyleSheet(
        "QListWidget { background-color: #9c9c9c; font-size: 18px; border-radius: 13px;} "
        "QMainWindow { background-color: #4f4f4f; }"
        "QPushButton { background-color: green; font-size: 20px; border-radius: 13px; }"
        "QLineEdit { background-color: white; font-size: 15px; border-radius: 13px; }")
    sys.excepthook = except_hook
    wnd = Window()
    wnd.show()
    sys.exit(app.exec())
